﻿namespace CarWebApp.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string CarMake { get; set; }
        public string CarModel { get; set; }

        public Car()
        {

        }
    }
}
